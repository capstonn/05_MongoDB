const user = require('./07 user.js');
const hello = require('./08 hello.js');
console.log(user);
console.log(hello);

hello(user);
