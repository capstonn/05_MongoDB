const { user1, user2 } = require('./10 users-1');
const hello = require('./08 hello');
hello(user1);
hello(user2);
