import { hi, goodbye } from './14 greeting-1.mjs';

goodbye('홍길동');
