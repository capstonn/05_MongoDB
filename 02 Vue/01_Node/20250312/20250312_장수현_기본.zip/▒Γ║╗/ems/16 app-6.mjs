import { hi, goodbye } from './14 greeting-1.mjs';

hi('홍길동');
goodbye('홍길동');
