const fs = require('fs');

const data = fs.readFileSync('./20250313/기본/example.txt', 'utf8');
console.log(data);
