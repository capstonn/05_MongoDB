package ch06.sec06.exam01;

public class Car {
        String model;
        boolean start;
        int speed;
    }
    //각 멤버 변수가 가지는 기본값은 model, start, speed 입니다.

